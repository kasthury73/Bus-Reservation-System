import java.io.*;
import java.util.HashMap;
import java.util.Map;

// Bus class
class Bus {
    private final String busNumber;
    private final int totalSeats;
    private final String startPoint;
    private final String endPoint;
    private final String startTime;
    private final double fare;

    public Bus(String busNumber, int totalSeats, String startPoint, String endPoint, String startTime, double fare) {
        this.busNumber = busNumber;
        this.totalSeats = totalSeats;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.startTime = startTime;
        this.fare = fare;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public String getStartPoint() {
        return startPoint;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public String getStartTime() {
        return startTime;
    }

    public double getFare() {
        return fare;
    }

    @Override
    public String toString() {
        return busNumber + "," + totalSeats + "," + startPoint + "," + endPoint + "," + startTime + "," + fare;
    }
}

// BusRegistration class
class BusRegistration {
    private final Map<String, Bus> busRegistry = new HashMap<>();
    private final String busFile = "bus.txt";

    public BusRegistration() {
        loadBusesFromFile();
    }

    public void registerBus(Bus bus) {
        if (busRegistry.containsKey(bus.getBusNumber())) {
            System.out.println("Bus with number " + bus.getBusNumber() + " is already registered.");
        } else {
            busRegistry.put(bus.getBusNumber(), bus);
            saveBusesToFile();
            System.out.println("Bus registered successfully: " + bus);
        }
    }

    public Bus getBusByNumber(String busNumber) {
        return busRegistry.get(busNumber);
    }

    public void viewAllBuses() {
        if (busRegistry.isEmpty()) {
            System.out.println("No buses registered.");
        } else {
            System.out.println("Registered Buses:");
            for (Bus bus : busRegistry.values()) {
                System.out.println(bus);
            }
        }
    }

    private void saveBusesToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(busFile))) {
            for (Bus bus : busRegistry.values()) {
                writer.write(bus.toString() + "\n");
            }
        } catch (IOException ex) {
            System.out.println("Error saving buses to file: " + ex.getMessage());
        }
    }

    private void loadBusesFromFile() {
        File file = new File(busFile);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 6) {
                    Bus bus = new Bus(
                            parts[0], Integer.parseInt(parts[1]), parts[2], parts[3], parts[4], Double.parseDouble(parts[5]));
                    busRegistry.put(bus.getBusNumber(), bus);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading buses: " + e.getMessage());
        }
    }
}