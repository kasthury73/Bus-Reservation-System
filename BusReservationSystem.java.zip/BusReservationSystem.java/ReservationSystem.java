import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
class ReservationSystem {
    private final Map<String, Queue<Customer>> reservations = new HashMap<>();
    private final Map<String, Queue<Customer>> waitingList = new HashMap<>();
    private final String reservationFile = "reservation.txt";
    private final String waitingListFile = "waiting_list.txt";

    public ReservationSystem() {
        loadReservationsFromFile();
        loadWaitingListFromFile();
    }

    public void reserveSeat(Customer customer, String busNumber, BusRegistration busReg) {
        Bus bus = busReg.getBusByNumber(busNumber);
        if (bus == null) {
            System.out.println("No such bus registered with number: " + busNumber);
            return;
        }

        int capacity = bus.getTotalSeats();
        Queue<Customer> busQueue = reservations.computeIfAbsent(busNumber, _ -> new LinkedList<>());

        if (busQueue.contains(customer)) {
            System.out.println("Customer already has a reservation.");
        } else if (busQueue.size() < capacity) {
            busQueue.offer(customer);
            saveReservationsToFile();
            System.out.println("Seat reserved for " + customer);
        } else {
            waitingList.computeIfAbsent(busNumber, _ -> new LinkedList<>());
            saveWaitingListToFile();
            System.out.println("Bus is full, added to waiting list for " + customer);
        }
    }

    public void cancelReservation(Customer customer, String busNumber) {
        Queue<Customer> busQueue = reservations.get(busNumber);
        if (busQueue != null && busQueue.remove(customer)) {
            saveReservationsToFile();
            System.out.println("Reservation canceled for " + customer);
        } else {
            System.out.println("No reservation found for " + customer);
        }
    }

    public void viewReservations(String busNumber) {
        Queue<Customer> busQueue = reservations.get(busNumber);
        if (busQueue != null) {
            System.out.println("Reservations for Bus " + busNumber + ":");
            for (Customer customer : busQueue) {
                System.out.println(customer);
            }
        } else {
            System.out.println("No reservations found for Bus " + busNumber);
        }
    }

    private void saveReservationsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(reservationFile))) {
            for (Map.Entry<String, Queue<Customer>> entry : reservations.entrySet()) {
                for (Customer customer : entry.getValue()) {
                    writer.write(entry.getKey() + "," + customer.getName() + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("Error saving reservations: " + e.getMessage());
        }
    }

    private void loadReservationsFromFile() {
        File file = new File(reservationFile);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String busNumber = parts[0];
                    Customer customer = new Customer(parts[1], "N/A", "N/A", "N/A", 0); // Adjust as necessary
                    reservations.computeIfAbsent(busNumber, _ -> new LinkedList<>()).offer(customer);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading reservations: " + e.getMessage());
        }
    }

    private void saveWaitingListToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(waitingListFile))) {
            for (Map.Entry<String, Queue<Customer>> entry : waitingList.entrySet()) {
                for (Customer customer : entry.getValue()) {
                    writer.write(entry.getKey() + "," + customer.getName() + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("Error saving waiting list: " + e.getMessage());
        }
    }

    private void loadWaitingListFromFile() {
        File file = new File(waitingListFile);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    String busNumber = parts[0];
                    Customer customer = new Customer(parts[1], "N/A", "N/A", "N/A", 0); // Adjust as necessary
                    waitingList.computeIfAbsent(busNumber, _ -> new LinkedList<>()).offer(customer);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading waiting list: " + e.getMessage());
        }
    }
}
