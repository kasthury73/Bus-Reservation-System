import java.util.*;

class Bus {
    private final String busNumber;
    private final int totalSeats;
    private final String startPoint;
    private final String endPoint;
    private final String startTime;
    private final double fare;

    public Bus(String busNumber, int totalSeats, String startPoint, String endPoint, String startTime, double fare) {
        this.busNumber = busNumber;
        this.totalSeats = totalSeats;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.startTime = startTime;
        this.fare = fare;
    }

    public String getBusNumber() {
        return busNumber;
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public String getStartPoint() {
        return startPoint;
    }

    public String getEndPoint() {
        return endPoint;
    }

    @Override
    public String toString() {
        return "Bus Number: " + busNumber + ", Seats: " + totalSeats + ", Route: " + startPoint + " to " + endPoint + ", Time: " + startTime + ", Fare: " + fare;
    }
}

class BusRegistration {
    private final Map<String, Bus> busRegistry = new HashMap<>();

    public void registerBus(Bus bus) {
        if (busRegistry.containsKey(bus.getBusNumber())) {
            System.out.println("Bus with number " + bus.getBusNumber() + " is already registered.");
        } else {
            busRegistry.put(bus.getBusNumber(), bus);
            System.out.println("Bus registered successfully: " + bus);
        }
    }

    public Bus getBusByNumber(String busNumber) {
        return busRegistry.get(busNumber);
    }

    public List<Bus> searchBuses(String startPoint, String endPoint) {
        List<Bus> matchingBuses = new ArrayList<>();
        for (Bus bus : busRegistry.values()) {
            if (bus.getStartPoint().equalsIgnoreCase(startPoint) && bus.getEndPoint().equalsIgnoreCase(endPoint)) {
                matchingBuses.add(bus);
            }
        }
        return matchingBuses;
    }

    public void viewAllBuses() {
        if (busRegistry.isEmpty()) {
            System.out.println("No buses registered.");
        } else {
            System.out.println("Registered Buses:");
            for (Bus bus : busRegistry.values()) {
                System.out.println(bus);
            }
        }
    }
}

class Customer {
    private String name;
    private final String mobileNumber;
    private final String email;
    private final String city;
    private final int age;

    public Customer(String name, String mobileNumber, String email, String city, int age) {
        this.name = name;
        this.mobileNumber = mobileNumber;
        this.email = email;
        this.city = city;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Name: " + name + ", Mobile: " + mobileNumber + ", Email: " + email + ", City: " + city + ", Age: " + age;
    }
}

class CustomerRegistration {
    private final Map<String, Customer> customers = new HashMap<>();

    public void registerCustomer(Customer customer) {
        customers.put(customer.getName(), customer);
        System.out.println("Customer registered successfully.");
    }

    public Customer getCustomerByName(String name) {
        return customers.get(name);
    }

    public void viewAllCustomers() {
        if (customers.isEmpty()) {
            System.out.println("No customers registered.");
        } else {
            System.out.println("Registered Customers:");
            for (Customer customer : customers.values()) {
                System.out.println(customer);
            }
        }
    }
}

class ReservationSystem {
    private final Map<String, Queue<Customer>> reservations = new HashMap<>();
    private final Map<String, Queue<Customer>> waitingList = new HashMap<>();

    public void reserveSeat(Customer customer, String busNumber, BusRegistration busReg) {
        Bus bus = busReg.getBusByNumber(busNumber);
        if (bus == null) {
            System.out.println("No such bus registered with number: " + busNumber);
            return;
        }

        int capacity = bus.getTotalSeats();
        Queue<Customer> busQueue = reservations.computeIfAbsent(busNumber, _ -> new LinkedList<>());

        if (busQueue.contains(customer)) {
            System.out.println("Customer already has a reservation. Use option 8 to request additional seat.");
        } else if (busQueue.size() < capacity) {
            busQueue.offer(customer);
            System.out.println("Seat reserved for " + customer.toString());
        } else {
            waitingList.computeIfAbsent(busNumber, key -> new LinkedList<>()).offer(customer);
            System.out.println("Bus is full, added to waiting list for " + customer.toString());
        }
    }

    public void reserveAdditionalSeat(Customer customer, String busNumber) {
        Queue<Customer> reservedQueue = reservations.get(busNumber);
        
        if (reservedQueue != null && reservedQueue.contains(customer)) {
            waitingList.computeIfAbsent(busNumber, _ -> new LinkedList<>()).offer(customer);
            System.out.println("Additional seat request added to waiting list for " + customer.getName());
        } else {
            System.out.println("Please request your seat through option 6.");
        }
    }

    public boolean cancelReservation(Customer customer, String busNumber) {
        Queue<Customer> busQueue = reservations.get(busNumber);
        if (busQueue != null && busQueue.remove(customer)) {
            System.out.println("Reservation canceled for " + customer.getName());
            System.out.println("---- Dear passenger " + customer.getName()+" your set has been canceled sucessfully!!! ----");
            
            // Notify co-passengers about the cancellation
            for (Customer coPassenger : busQueue) {
                System.out.println("---- Dear passenger " + coPassenger.getName() + ", your co-passenger " + customer.getName() + " canceled their seat just now ----");
            }
            
            if (!waitingList.getOrDefault(busNumber, new LinkedList<>()).isEmpty()) {
                Customer nextCustomer = waitingList.get(busNumber).poll();
                busQueue.offer(nextCustomer);
                System.out.println("---- Dear customer " + nextCustomer.getName() + " Your seat is now booked... ----");
                System.err.println(" ");
                System.out.println("!!! Waiting list customer " + nextCustomer.getName() + " has been moved to reservation !!!");
                System.err.println(" ");
            }
            return true;
        } else {
            System.out.println("No reservation found for " + customer.getName());
            return false;
        }
    }

    public void viewReservations(String busNumber) {
        Queue<Customer> busQueue = reservations.get(busNumber);
        if (busQueue != null) {
            System.out.println("Reservations for Bus " + busNumber + ":");
            for (Customer customer : busQueue) {
                System.out.println(customer);
            }
        } else {
            System.out.println("No reservations found for Bus " + busNumber);
        }
    }

    public void viewWaitingList(String busNumber) {
        Queue<Customer> waitQueue = waitingList.get(busNumber);
        if (waitQueue != null) {
            System.out.println("Waiting List for Bus " + busNumber + ":");
            for (Customer customer : waitQueue) {
                System.out.println(customer);
            }
        } else {
            System.out.println("No waiting list found for Bus " + busNumber);
        }
    }
}

public class BusReservationMain {
    public static void main(String[] args) {
        CustomerRegistration customerReg = new CustomerRegistration();
        ReservationSystem reservationSystem = new ReservationSystem();
        BusRegistration busReg = new BusRegistration();
        
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("1. Register Customer");
                System.out.println("2. View Registered Customers");
                System.out.println("3. Register New Bus");
                System.out.println("4. View Registered Buses");
                System.out.println("5. Search Bus");
                System.out.println("6. Reserve Seat");
                System.out.println("7. View Reservations");
                System.out.println("8. Additional Seat Request");
                System.out.println("9. Cancel Seat Reservation");
                System.out.println("10. View Waiting Queue");
                System.out.println("11. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        System.out.print("Enter Name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter Mobile: ");
                        String mobile = scanner.nextLine();
                        System.out.print("Enter Email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter City: ");
                        String city = scanner.nextLine();
                        System.out.print("Enter Age: ");
                        int age = scanner.nextInt();
                        scanner.nextLine();
                        Customer customer = new Customer(name, mobile, email, city, age);
                        customerReg.registerCustomer(customer);
                        break;

                    case 2:
                        customerReg.viewAllCustomers();
                        break;

                    case 3:
                        System.out.print("Enter Bus Number: ");
                        String busNumber = scanner.nextLine();
                        System.out.print("Enter Total Seats: ");
                        int seats = scanner.nextInt();
                        scanner.nextLine();
                        System.out.print("Enter Start Point: ");
                        String startPoint = scanner.nextLine();
                        System.out.print("Enter End Point: ");
                        String endPoint = scanner.nextLine();
                        System.out.print("Enter Start Time: ");
                        String startTime = scanner.nextLine();
                        System.out.print("Enter Fare: ");
                        double fare = scanner.nextDouble();
                        scanner.nextLine();
                        Bus bus = new Bus(busNumber, seats, startPoint, endPoint, startTime, fare);
                        busReg.registerBus(bus);
                        break;

                    case 4:
                        busReg.viewAllBuses();
                        break;

                    case 5:
                        System.out.print("Enter Start Point: ");
                        startPoint = scanner.nextLine();
                        System.out.print("Enter End Point: ");
                        endPoint = scanner.nextLine();
                        List<Bus> buses = busReg.searchBuses(startPoint, endPoint);
                        if (buses.isEmpty()) {
                            System.out.println("No buses found for the specified route.");
                        } else {
                            System.out.println("Available Buses:");
                            for (Bus b : buses) {
                                System.out.println(b);
                            }
                        }
                        break;

                    case 6:
                        System.out.print("Enter Customer Name: ");
                        name = scanner.nextLine();
                        customer = customerReg.getCustomerByName(name);
                        if (customer != null) {
                            System.out.print("Enter Bus Number: ");
                            busNumber = scanner.nextLine();
                            reservationSystem.reserveSeat(customer, busNumber, busReg);
                        } else {
                            System.out.println("Customer not found.");
                        }
                        break;

                    case 7:
                        System.out.print("Enter Bus Number to View Reservations: ");
                        busNumber = scanner.nextLine();
                        reservationSystem.viewReservations(busNumber);
                        break;

                    case 8:
                        System.out.print("Enter Customer Name for Additional Seat Request: ");
                        name = scanner.nextLine();
                        customer = customerReg.getCustomerByName(name);
                        if (customer != null) {
                            System.out.print("Enter Bus Number: ");
                            busNumber = scanner.nextLine();
                            reservationSystem.reserveAdditionalSeat(customer, busNumber);
                        } else {
                            System.out.println("Customer not found.");
                        }
                        break;

                    case 9:
                        System.out.print("Enter Customer Name to Cancel Reservation: ");
                        name = scanner.nextLine();
                        customer = customerReg.getCustomerByName(name);
                        if (customer != null) {
                            System.out.print("Enter Bus Number: ");
                            busNumber = scanner.nextLine();
                            reservationSystem.cancelReservation(customer, busNumber);
                        } else {
                            System.out.println("Customer not found.");
                        }
                        break;

                    case 10:
                        System.out.print("Enter Bus Number to View Waiting Queue: ");
                        busNumber = scanner.nextLine();
                        reservationSystem.viewWaitingList(busNumber);
                        break;

                    case 11:
                        System.out.println("Exiting...");
                        return;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    } 
}
