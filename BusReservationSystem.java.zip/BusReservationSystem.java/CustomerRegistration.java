import java.io.*;
import java.util.*;

// Customer class to represent customer data
class Customer {
    private final String name;
    private final String mobileNumber;
    private final String email;
    private final String city;
    private final int age;

    // Constructor to initialize customer details
    public Customer(String name, String mobileNumber, String email, String city, int age) {
        this.name = name;
        this.mobileNumber = mobileNumber;
        this.email = email;
        this.city = city;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    // Override toString to create a formatted string for saving to file
    @Override
    public String toString() {
        return name + ", " + mobileNumber + ", " + email + ", " + city + ", " + age;
    }
}

// CustomerRegistration class to manage the customer data
class CustomerRegistration {
    private final Map<String, Customer> customers = new HashMap<>();
    private final String customerFile = "customers.txt";  // Path to the file storing customer data

    // Constructor initializes the customer list from file
    public CustomerRegistration() {
        loadCustomersFromFile();
    }

    // Method to register a new customer
    public void registerCustomer(Customer customer) {
        customers.put(customer.getName(), customer);  // Add customer to map
        saveCustomersToFile();  // Save updated customer list to file
        System.out.println("Customer registered successfully.");
    }

    // Method to retrieve a customer by their name
    public Customer getCustomerByName(String name) {
        return customers.get(name);
    }

    // Method to display all registered customers
    public void viewAllCustomers() {
        if (customers.isEmpty()) {
            System.out.println("No customers registered.");
        } else {
            System.out.println("Registered Customers:");
            for (Customer customer : customers.values()) {
                System.out.println(customer);
            }
        }
    }

    // Method to save the customer data to a text file
    private void saveCustomersToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(customerFile))) {
            for (Customer customer : customers.values()) {
                writer.write(customer.toString());
                writer.newLine();  // Write each customer on a new line
            }
        } catch (IOException e) {
            System.out.println("Error saving customers: " + e.getMessage());
        }
    }

    // Method to load customer data from the text file into the customers map
    private void loadCustomersFromFile() {
        File file = new File(customerFile);  // Check if file exists
        if (!file.exists()) return;  // If file doesn't exist, no data to load

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");  // Split the line by ", "
                if (parts.length == 5) {  // Ensure there are exactly 5 parts
                    Customer customer = new Customer(
                        parts[0],        // Name
                        parts[1],        // Mobile Number
                        parts[2],        // Email
                        parts[3],        // City
                        Integer.parseInt(parts[4]) // Age
                    );
                    customers.put(customer.getName(), customer);  // Add to map
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading customers: " + e.getMessage());
        }
    }
}
